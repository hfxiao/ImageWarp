function [] = DispMesh( Vertex, GridSz, Color, Wid )
% function [] = DispMesh( Vx, Vy, Color, Wid )
%=====================Input==================================
%   Vx: m-by-n matrix. Vx(i,j) is the the x-coordinate
%       of the i-th (in row) and j-th (in column) vertex.
%   Vy(i,j) is corresponding y-coordinate.
%
%   Vertex: 2*m*n-by-1 vector, (x;y;x;y) in column-first order
%   GridSz: [m;n]
%=====================Output=================================
%
%=====================Description==============================
%   This function show the meshes on the displayed image.

narginchk(2,4);
m = GridSz(1);  n = GridSz(2);
Vx = reshape( Vertex( 1:2:end-1 ), m, n );
Vy = reshape( Vertex( 2:2:end ), m, n );
if ( nargin<3 || isempty(Color) ); Color = [1,1,0]; end;
if ( nargin<4 || isempty(Wid) ); Wid = 3; end;

hold on
plot( reshape([Vx;NaN(1,n)],1,[]), reshape([Vy;NaN(1,n)],1,[]), 'Color', Color, 'LineWidth', Wid );
plot( reshape(transpose([Vx,NaN(m,1)]),1,[]), reshape(transpose([Vy,NaN(m,1)]),1,[]), 'Color', Color, 'LineWidth', Wid );
hold off

end