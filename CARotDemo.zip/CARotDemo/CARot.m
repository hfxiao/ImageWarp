function [ I1 ] = CARot( I0, UI, Opt )
%=====================Input==================================
%   I0: H-by-W-by-3 RGB double Original Image.
%   UI: 2-by-2 matrix, the User-Specified Points to Calculate the Roration Angle
%
%=====================Output=================================
%   I1: H-by-W-by-3 RGB uint8 Rotated Image
%
%=====================Description==============================
%   This function implements the approach proposed in the paper 
%   "Kaiming He et al, Content-Aware Rotation, ICCV 2013".
%
%   The implementation is written by Hongfei Xiao (hfxiao.casia@gmail.com)
%
%   The Oxy Co-ordinate system, X: Cols, Y: Rows

cc
%%  0)    ParseInputs: UI2Angle and Size of Image
ticAll = tic;
[h,w,~] = size(I0);
[ Delta, Angle ] = UI2Angle( UI );%Delta: the rorated angle, with radian measure.
[ m, n, M, dm, lb, ll, lr ] = deal( Opt.GridSz(1), Opt.GridSz(2), Opt.M, Opt.deltam, Opt.LambdaB, Opt.LambdaL, Opt.LambdaR );

%%  1.a)    Initial Mesh Generation
xpos = linspace(0,w,n);
ypos = linspace(0,h,m);
Vertex = reshape( [ reshape(repmat( xpos,m,1 ),1,[]); reshape(transpose(repmat( ypos,n,1 )),1,[]) ], [], 1 ); % 2*m*n-by-1 vector
% according to the lines' coordinate, Vertex should start from 0, not 1.
xdis = w/(n-1);
ydis = h/(m-1);
nV = 2*m*n;
Q = (m-1)*(n-1); % the number of quads

%%  1.b)    LSD Detection
LS0 = CallLSD( I0, -1 ); % K-by-4 matrix, the detected line segments on the original (before rotation) image

%%  1.c)    Line Segments Cut by Mesh Edges
[ LS, ~, IdEX, IdEY ] = MexCutLS( LS0, xpos, ypos );
% [ LS, IdLS0, IdEX, IdEY ] = MexCutLS( LS0, xpos, ypos ); % LS(:,1)<=LS(:,3) have been adjusted.
K = size(LS,1);
% clear LS0;
uk = [ LS(:,3)-LS(:,1), LS(:,4)-LS(:,2) ];  % K-by-2 matrix, in paper directional vector uk of each original line segments.
% Len = sqrt(sum( uk.^2, 2 )); % K-by-1 vector, the length of the original line segments
Phi0 = atan( uk(:,2)./uk(:,1) ); % K-by-1 vector, the original angle of the detected line segments. not accounted for 0 denominator.

%%  1.d)    Uk and Pk Calculation
Uk = [ uk(:,1).^2, uk(:,1).*uk(:,2) ]./repmat(sum( uk.^2, 2 ),1,2); % K-by-2
SubJ = [ 2*(IdEY+(IdEX-1)*m)-1, 2*(IdEY+(IdEX-1)*m) , 2*(IdEY+IdEX*m)-1, 2*(IdEY+IdEX*m),...
            2*(IdEY+1+IdEX*m)-1, 2*(IdEY+1+IdEX*m) , 2*(IdEY+1+(IdEX-1)*m)-1, 2*(IdEY+1+(IdEX-1)*m) ]; % K-by-8 subscript matrix
Pk = cell(K,1);
for k = 1:K
    SEq = zeros(8,nV);
    SEq( sub2ind( size(SEq), 1:8, SubJ(k,:) ) ) = 1;
    
    mux1 = ( xpos(IdEX(k)+1)-LS(k,1) )/xdis;
    muy1 = ( ypos(IdEY(k)+1)-LS(k,2) )/ydis;
    mux2 = ( xpos(IdEX(k)+1)-LS(k,3) )/xdis;
    muy2 = ( ypos(IdEY(k)+1)-LS(k,4) )/ydis;
    Pk{k} = [ [ mux1*muy1, 0, (1-mux1)*muy1, 0, (1-mux1)*(1-muy1), 0, mux1*(1-muy1), 0 ];...
                  [ 0, mux1*muy1, 0, (1-mux1)*muy1, 0, (1-mux1)*(1-muy1), 0, mux1*(1-muy1) ];...
                  [ mux2*muy2, 0, (1-mux2)*muy2, 0, (1-mux2)*(1-muy2), 0, mux2*(1-muy2), 0 ];...
                  [ 0, mux2*muy2, 0, (1-mux2)*muy2, 0, (1-mux2)*(1-muy2), 0, mux2*(1-muy2) ] ]* SEq;
    %Pk{k}: 4-by-nV matrix
end
% clear SubJ SEq;

%%  1.e)    Orietation of Lines Assigned into Bins
Phi = Phi0+Delta;
Phi(Phi<0) = pi+Phi(Phi<0);

IdBin = floor( Phi*M/pi )+1; % K-by-1, IdBin = min( floor( Phi*M/pi )+1, M ) ; % min for possible Phi==pi
KeyBins = [ 1, M/2, M/2+1, M ];
IfKey = ismember( IdBin, KeyBins ); % ismember, not intersect
figure(19); imshow(uint8(I0));  DispMesh(Vertex,[m,n]); DispLines( LS, IfKey );
set(gcf,'Name','The Input Mesh and Line Segments','outerposition',get(0,'screensize'));
% clear Phi Phi0;

Tmp = sortrows( [ IdBin, (1:K).'] );
InBin = Tmp(:,2); % K-by-1 vector, can be partitioned as the mapping from bins to line segments
IdColLT = Tmp(:,1); % K-by-1 vector, [ 1*ones(hist(1),1); 2*ones(hist(2),1); ... ]

%%  2)  Vertex and Theta Optimization
%%  2.a)    Boundary Preservation for Vertex
% B: 2*(m+n)-by-nV  (sparse and large) matrix.
rows = 2*(m+n);
B = sqrt(lb)*sparse( 1:rows, [ 2*(1:m)-1, 2*((1:m)+(n-1)*m)-1, 2*(1+(0:n-1)*m), 2*(m+(0:n-1)*m) ], ones(rows,1), rows, nV );
yb = sqrt(lb)*[ zeros(m,1); w*ones(m,1); zeros(n,1); h*ones(n,1) ]; %2*(m+n)-by-1 vector

%%  2.b)    Rotation Manipulation for Theta
% R: M+3-by-M  (sparse and large) matrix.
R = sqrt(lr)*sparse( [ 1:M-1, 1:M-1, M:M+3 ], [ 1:M-1, 2:M, KeyBins ], [ ones(M-1,1); -1*ones(M-1,1); sqrt(dm)*ones(4,1) ], M+3, M );
yr =  sqrt(lr)*[ zeros(M-1,1); sqrt(dm)*Delta*ones(4,1) ];%M+3-by-1 vector

%%  2.c)    Half-Quadratic Splitting Psi for Theta
% LT: K-by-M (sparse and large) matrix
LT = sparse( 1:K, IdColLT, ones(K,1), K, M );

%%  2.d)    Main Loop
% Theta = Delta*ones(M,1);
ThetaBin = Delta*ones(K,1);
for Iter = 1:Opt.OutMaxIter
    disp('                                                                                                      ');
    disp([ '************** ', num2str(Iter), '-th Outer Iteration', ' **************' ])
    disp('                                                                                                      ');
    %%  2.d.i)  Update Vertex
    S = CalShape( Vertex, m, n ); % S: 8*Q-by-nV
    LV = CalRotLine( nV, ThetaBin, Pk, Uk ); % LV: 2*K-by-nV
    Vertex = lsqr( [ sqrt(1/Q)*S; sqrt(ll/K)*LV; B ], [ zeros(8*Q+2*K,1); yb ], 1e-10, 1e4, [], [], Vertex );
%     Vertex = lsqr( [ sqrt(ll/K)*LV; B ], [ zeros(2*K,1); yb ], 1e-10, 1e4, [], [], Vertex ); % if no shape preservation term
    Vertex(abs(Vertex)<1e-3) = 0;
%     Vertex(2*((1:m)+(n-1)*m)-1) = w; % no need to do so in the main loop.
%     Vertex(2*(m+(0:n-1)*m)) = h;
    figure(11); subplot(3,4,Iter);  imshow(uint8(I0));  DispMesh(Vertex,[m,n],[],1);
    set(gcf,'Name','MeshOptimizing','outerposition',get(0,'screensize'));
%     ek = transpose(reshape( cell2mat(Pk)*Vertex, 2, [] )); % K-by-2 matrix, in paper directional vector ek of each rotated line segments.
    RotLS = transpose(reshape( cell2mat(Pk)*Vertex, 4, [] ));
    ek = [ RotLS(:,3)-RotLS(:,1), RotLS(:,4)-RotLS(:,2) ]; % K-by-2 matrix, in paper directional vector ek of each rotated line segments.
%     figure; imshow(uint8(I0));  DispMesh(Vertex,[m,n]); DispLines(RotLS,IfKey);
    
    %%  2.d.ii) Update Theta
    beta = Opt.beta0;
    while beta<Opt.betamax
        disp([ '===== ', 'beta = ', num2str(beta), ' =====' ])
        %   Update Psi
        AngleEU=atan( (uk(:,1).*ek(:,2)-uk(:,2).*ek(:,1))./(uk(:,1).*ek(:,1)+uk(:,2).*ek(:,2)) ); % K-by-1 vector
        CandiPsi = cell2mat( arrayfun( @linspace, AngleEU, ThetaBin, 'UniformOutput', 0 ) ); % K-by-100 matrix
        PsiCost = MexPsiCost( CandiPsi, ThetaBin, Uk, ek, beta, ll ); % K-by-100 matrix, Energy of CandiPsi
        [~,IdMin] = min( PsiCost, [], 2 );
        Psi = CandiPsi( sub2ind( [K,100], (1:K).', IdMin ) );
        
        %   Update Theta
        Theta = lsqr( [ R; sqrt(beta)*LT ], [yr; sqrt(beta)*Psi(InBin) ], 1e-10, 1e4 );
        ThetaBin = Theta(IdBin); % K-by-1 vector, theta_{m(k)} in paper
        
        %   Update beta
        beta = beta*Opt.betastep;
    end
end
% Vertex(abs(Vertex)<1e-3) = 0; % should be in the main loop
Vertex(2*((1:m)+(n-1)*m)-1) = w; % if not black holes on the right boundary
Vertex(2*(m+(0:n-1)*m)) = h;

%%  3)  Interpolation with the Mesh between the Vertex
figure(Iter); imshow(uint8(I0));  DispMesh(Vertex,[m,n]); DispLines(RotLS,IfKey);
set(gcf,'Name','The Final Mesh and Line Segments','outerposition',get(0,'screensize'));
I1 = InterpImg( I0, Vertex, [m,n] );
AllTime = toc(ticAll);

%%  4)  Display and Save Results
if Opt.FigId>0
    figure(Opt.FigId)
    subplot 221; imshow(uint8(I0));  DispLines( LS, IfKey );% original LS shown with Canonical Bins Highlighted
    title({ [ 'Among ', num2str(K),' Detected Line Segments on the input image, ' ] ; [num2str( length(find(IfKey)) ), ' LS will be Horizontal or Vertical.'] });
    subplot 222; imshow(I1); DispLines(RotLS,IfKey);% rorated LS shown with Canonical Bins Highlighted
    title( 'Canonical Line Segments on the Rotated Image' );
    subplot 223; imshow(I1); DispMesh(Vertex,[m,n]);% The Rotated Image shown with the Optimized Mesh
    title({ 'The Optimized Mesh'; Opt.ParaString });
    subplot 224;    imshow(I1);
    title({ [ 'The Output Image Rotated by ', num2str(Angle), ' degree' ]; [ 'Time = ', num2str(AllTime) ] });
    set(gcf,'Name','','outerposition',get(0,'screensize'));
    
    figure(Opt.FigId+1);
    imshow(I1);
    set(gcf,'Name','Output Image','outerposition',get(0,'screensize'));
end
imwrite( I1, ['Images/myrot',Opt.ImgName,'.png'], 'png' );

end



%%  Auxiliary Functions
function [Delta, Angle] = UI2Angle( UI ) % some bugs to calculate Delta @140314
%   this function returns the rotated angles ( in radian measure ) of the
%   rotated image.

deltay = UI(2,2) - UI(1,2);
deltax = UI(2,1) - UI(1,1);
rad = atan( deltay / deltax );
if rad>0
    if abs(deltay)>abs(deltax)
        Delta = pi/2-rad;%signed angle in radian measure
    else
        Delta = -rad;%if rorated clockwise, Delta be positive, negative otherwise.
    end
    %   The direction of the rorated line segments will be Phi+Delta
else
    if abs(deltay)>abs(deltax)
        Delta = -pi/2-rad;
    else
        Delta = -pi-rad;
    end
end
Angle = Delta*180/pi;%signed angle in angle measure

end

function S = CalShape( Vertex, m, n )
%=====================Input==================================
%   Vertex: nV-by-1 vector, (x;y;x;y) in column-first order. nV = 2*m*n
%   
%=====================Output=================================
%   S: 8*Q-by-nV  (sparse and large) matrix for Vertex
%
%=====================Description==============================
%   This function calculate the coefficients matrix S of the Least-Square
%   Problem in the shape preservation energy.
%   In the future, this function will be replaced by C++ implementation ( if runs slowly ).
%
%   i-th row and j-th column vetex [ x_ij; y_ij ] is at the q-th index of
%   the Vertex. where qx(i,j) = 2*( i+(j-1)*m )-1, qy(i,j) = 2*( i+(j-1)*m).

%%  1.a)    Variables
Per = zeros(8,8);
Per(1,2)=-1;    Per(2,1)=1;     Per(3,4)=-1;    Per(4,3)=1;     Per(5,6)=-1;    Per(6,5)=1;     Per(7,8)=-1;    Per(8,7)=1;
%   Per is used to transpose the Vertex into [-y;x;-y;x] storage, correponding to the 2-nd column of Aq
I8 = eye(8);

nV = size(Vertex,1);
Q= (m-1)*(n-1);
S = zeros( 8*Q, nV );
iv = (1:8)'; jv = ones(8,1); val = ones(8,1);
for q = 1:Q% in column-first order
    i = mod(q-1,m-1)+1;
    j = ceil(q/(m-1));
    jv(1) = 2*(i+(j-1)*m)-1; jv(2) = 2*(i+(j-1)*m);     jv(3) = 2*(i+j*m)-1; jv(4) = 2*(i+j*m);
    jv(5) = 2*(i+1+j*m)-1; jv(6) = 2*(i+1+j*m);     jv(7) = 2*(i+1+(j-1)*m)-1; jv(8) = 2*(i+1+(j-1)*m);
    SEq = sparse( iv, jv, val, 8, nV ); % element selecting matrix
    Vq = reshape( SEq*Vertex, 2, 4 );
    Vq = reshape( Vq-repmat(mean(Vq,2),1,4), 8, 1 );%Centerize. Ref to Mingming Chen's implementation
    Aq = [ Vq, Per*Vq, repmat(eye(2),4,1) ]; %8-by-4
    S( (8*(q-1)+1) : (8*q), : ) = (Aq*pinv(Aq)-I8)*SEq;
end
S = sparse(S);

end

function LV = CalRotLine( nV, ThetaBin, Pk, Uk )
%=====================Input==================================
%   Vertex: nV-by-1 vector, (x;y;x;y) in column-first order. nV = 2*m*n
%   Theta: M-by-1 vector, the common rorated angle of each bin.
%   IdBin: K-by-1 vector, the indexes of each direction vector assigned to bins.
%   ThetaBin === Theta(IdBin), K-by-1
% % %   Pk: K-by-1 cell, each is 2-by-nV matrix. ek = Pk{k}*V
%   Pk: K-by-1 cell, each is 4-by-nV matrix. Rotated LS(k,:) = Pk{k}*V
% % %   Uk: K-by-1 cell, each is 2-by-2 matrix. Uk in the paper
%   Uk: K-by-2. the k-th row: [ Uk(1,1),Uk(2,1) ];
%=====================Output=================================
%   LV: 2*K-by-nV matrix.
%
%=====================Description==============================
%   This function calculate the coefficients matrix L of the Least-Square
%   Problem in the line preservation energy.
%   In the future, this function will be replaced by C++ implementation.

I2 = eye(2);
% nV = size(Vertex,1);
K = size(Uk,1);
LV = zeros( 2*K, nV );
for k = 1:K
    angle = ThetaBin(k);
    Rk = [ cos(angle), -sin(angle); sin(angle), cos(angle) ];
%     LV( [2*k-1,2*k], : ) = ( Rk*Uk{k}*Rk.' - I2 )*Pk{k};
%     LV( [2*k-1,2*k], : ) = ( Rk*[ Uk(k,1), Uk(k,2); Uk(k,2), 1-Uk(k,1) ]*Rk.' - I2 )*Pk{k};
    LV( [2*k-1,2*k], : ) = ( Rk*[ Uk(k,1), Uk(k,2); Uk(k,2), 1-Uk(k,1) ]*Rk.' - I2 )*[ Pk{k}(3,:)-Pk{k}(1,:); Pk{k}(4,:)-Pk{k}(2,:) ];
end
LV = sparse(LV);

end

function [] = DispMesh( Vertex, GridSz, Color, Wid )
% function [] = DispMesh( Vx, Vy, Color, Wid )
%=====================Input==================================
%   Vx: m-by-n matrix. Vx(i,j) is the the x-coordinate
%       of the i-th (in row) and j-th (in column) vertex.
%   Vy(i,j) is corresponding y-coordinate.
%
%   Vertex: 2*m*n-by-1 vector, (x;y;x;y) in column-first order
%   GridSz: [m;n]
%=====================Output=================================
%
%=====================Description==============================
%   This function show the meshes on the displayed image.

narginchk(2,4);
m = GridSz(1);  n = GridSz(2);
Vx = reshape( Vertex( 1:2:end-1 ), m, n );
Vy = reshape( Vertex( 2:2:end ), m, n );
if ( nargin<3 || isempty(Color) ); Color = [1,1,0]; end;
if ( nargin<4 || isempty(Wid) ); Wid = 3; end;

hold on
plot( reshape([Vx;NaN(1,n)],1,[]), reshape([Vy;NaN(1,n)],1,[]), 'Color', Color, 'LineWidth', Wid );
plot( reshape(transpose([Vx,NaN(m,1)]),1,[]), reshape(transpose([Vy,NaN(m,1)]),1,[]), 'Color', Color, 'LineWidth', Wid );
hold off

end

function [] = DispLines( LS, IfKey, KeyColor, ElseColor, Wid )


narginchk(1,5);
if nargin>=2
    if ( nargin<3 || isempty(KeyColor) ); KeyColor = [1,0,0]; end;
    if ( nargin<4 || isempty(ElseColor) ); ElseColor = [0,1,0]; end;
    if ( nargin<5 || isempty(Wid) ); Wid = 2; end;
    
    hold on;
    K = size(LS,1);
    nKeys = length(find(IfKey));
    KeyLine = LS(IfKey,:);
    plot( reshape(transpose([KeyLine(:,1),KeyLine(:,3),NaN(nKeys,1)]),1,[]), reshape(transpose([KeyLine(:,2),KeyLine(:,4),NaN(nKeys,1)]),1,[]), ...
        'Color', KeyColor, 'LineWidth', Wid );
    ElseLine = LS(~IfKey,:);
    plot( reshape(transpose([ElseLine(:,1),ElseLine(:,3),NaN(K-nKeys,1)]),1,[]), reshape(transpose([ElseLine(:,2),ElseLine(:,4),NaN(K-nKeys,1)]),1,[]), ...
        'Color', ElseColor, 'LineWidth', Wid );
    hold off;
else
    hold on;
    K = size(LS,1);
    for k = 1:K
        plot( [LS(k,1),LS(k,3)], [LS(k,2),LS(k,4)], 'Color', rand(1,3), 'LineWidth', 3 );
    end
    hold off;
end

end

function I1 = InterpImg( I0, Vertex, GridSz )
%=====================Input==================================
%   I0: h-by-w-by-3 double image, the original image
%   Vertex: 2*m*n-by-1 matrix, [x;y;x;y...] in column first order
%   GridSz: [m,n]
%=====================Output=================================
%   I1: h-by-w-3 RGB image, the interpolated image
%=====================Description==============================
%

[h,w,~] = size(I0);
m = GridSz(1); n = GridSz(2);

%   wrong: the original points mapped to the rorated points
% nPixels = h*w;
% nV = size(Vertex,1);
% [x,y]=meshgrid(1:w,1:h);
% x = reshape(x,[],1);
% y = reshape(y,[],1);
% xpos = linspace(0,w,n);
% ypos = linspace(0,h,m);
% xdis = w/(n-1);
% ydis = h/(m-1);
% IdEX = ceil( x/xdis ); % h*w-by-1
% IdEY = ceil( y/ydis );
% SubJ = [ 2*(IdEY+(IdEX-1)*m)-1, 2*(IdEY+(IdEX-1)*m) , 2*(IdEY+IdEX*m)-1, 2*(IdEY+IdEX*m),...
%             2*(IdEY+1+IdEX*m)-1, 2*(IdEY+1+IdEX*m) , 2*(IdEY+1+(IdEX-1)*m)-1, 2*(IdEY+1+(IdEX-1)*m) ]; % nPixels-by-8 subscript matrix
% Xq = zeros(nPixels,1);
% Yq = zeros(nPixels,1);
% for k = 1:nPixels
%     SEq = zeros(8,nV);
%     SEq( sub2ind( size(SEq), 1:8, SubJ(k,:) ) ) = 1;
%     mux = ( xpos(IdEX(k)+1)-x(k) )/xdis; % nPixels-by-1, the intepolation coefficients
%     muy = ( ypos(IdEY(k)+1)-y(k) )/ydis;
%     Xq(k) = [mux,0,1-mux,0,1-mux,0,mux,0]/2*SEq*Vertex;
%     Yq(k) = [0,muy,0,muy,0,1-muy,0,1-muy]/2*SEq*Vertex;
% end

% % %   right: finding the original points corresponding the given rotated points 
% % Vx = reshape( Vertex( 1:2:end-1 ), m, n );
% % Vy = reshape( Vertex( 2:2:end ), m, n );
% % [ Xq, Yq, IdEX, IdEY ] = MexXqYq( Vx, Vy, h, w );
% % [ Xq, Yq, ~, ~ ] = MexXqYq( Vx, Vy, h, w ); % Calculate the backward mapping defined by Vertex.
% [ Xq, Yq, ~, ~ ] = MexXqYq( reshape( Vertex( 1:2:end-1 ), m, n ), reshape( Vertex( 2:2:end ), m, n ), h, w );

%   right 2: 
[ IdEX, IdEY ] = MexInQuad( Vertex, h, w, m, n ); % bugs: leading wrong IdEXY when the pixels are on the longitude (lattitude) of the mesh @140314
[ Xq, Yq ] = MexQuadXYq( Vertex, IdEX-1, IdEY-1, h, w, m, n ); % matlab index from 1 while C from 0.
Xq = max(min(Xq,w),1); % to exclude the <1 or >w Xq values and avoid black holes.
Yq = max(min(Yq,h),1);
I1 = zeros(h,w,3);
for c = 1:3
    I1(:,:,c) = reshape( interp2( I0(:,:,c), Xq, Yq ), h, w );
end
I1 = uint8(I1);

end
