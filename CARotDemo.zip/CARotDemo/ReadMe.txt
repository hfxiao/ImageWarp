This demo is an implementation for the paper "Kaiming He et al., Content-Aware Rotation, ICCV, 2013" written by Hongfei Xiao (email: hfxiao.casia@gmail.com).

The implementation is written with C++ and MATLAB, tested within MATLAB 2013b on a PC with Windows 7 64 bit. Compling commands for the C++ code can be found in the file Demo.m and DoCARot.m.

To run the code, please specify an input image and the rotation angle (in this implementation, choosing one slant line segments via user interactions). The options can be set by default. This command will run the program:

[ ImgRot ] = CARot( double(Img), UI, Opt );.

For more details, please refer to the papers:
He et al., Content-Aware Rotation, ICCV, 2013
He et al., Rectangling Panoramic Images via Warping, TOG, 2013. (the corresponding slides is also worth referring)
Chang et al., A Line-Structure-Preserving Approach to Image Resizing, CVPR, 2012
Zhang et al., A Shape-Preserving Approach to Image Resizing, Pacific Graphics 2009