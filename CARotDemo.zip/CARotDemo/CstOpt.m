function Opt = CstOpt(varargin)
% This function output the options or the parameters to use in the
% content-aware rotation (CARot)

%% Default Parameters
Opt.ImgName = [];

Opt.LSD = 0;

Opt.GridSz = [20,20];
Opt.M = 90;% the number of  bins for line segments direction. must be a even number.

Opt.deltam = 1e3;

Opt.LambdaB = 1e8;
Opt.LambdaL = 1e2;
Opt.LambdaR = 1e2;

Opt.OutMaxIter = 10;
Opt.beta0 = 1;
Opt.betastep = 10;
Opt.betamax = 1e4;

Opt.FigId = 437;

%% Parameters Setting According to Varargin
%Haven't Account for Fault Varargin such as wrong data type
for i = 1:2:nargin
    switch(varargin{i})
        case 'ImgName'
            Opt.ImgName = varargin{i+1};
        case 'LSD'
            Opt.LSD = varargin{i+1};
        case 'GridSz'
            Opt.GridSz = varargin{i+1};
        case 'M'
            Opt.M = varargin{i+1};
        case 'deltam'
            Opt.deltam = varargin{i+1};
        case 'LambdaB'
            Opt.LambdaB = varargin{i+1};
        case 'LambdaL'
            Opt.LambdaL = varargin{i+1};
        case 'LambdaR'
            Opt.LambdaR = varargin{i+1};
        case 'OutMaxIter'
            Opt.OutMaxIter = varargin{i+1};
        case 'beta0'
            Opt.beta0 = varargin{i+1};
        case 'betastep'
            Opt.betastep = varargin{i+1};
        case 'betamax'
            Opt.betamax = varargin{i+1};
        case 'FigId'
            Opt.FigId = varargin{i+1};
    end
end

%% Fields Constructed according to Opt.
Opt.ParaString = [ num2str(Opt.LSD), '-', num2str(Opt.GridSz), '-', num2str(Opt.M), '-', ...
                            num2str(Opt.deltam), '-', num2str([Opt.LambdaB,Opt.LambdaL,Opt.LambdaR]), '-', ...
                            num2str(Opt.OutMaxIter),'-', num2str([Opt.beta0,Opt.betastep,Opt.betamax]) ];                        
% Opt.SaveName = fullfile( Opt.ImgPath, 'output', [Opt.ImgName, '-(', Opt.ParaString, ')'] );
end