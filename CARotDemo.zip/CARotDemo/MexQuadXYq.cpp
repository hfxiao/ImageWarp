//=====================Input==================================
//  prhs[0-6]: Vertex, IdEdgeX, IdEdgeY, h, w, m, n.
//        Vertex: nV-by-1, nV = 2*m*n. The image is covered by a m-by-n mesh.
//          the coordinates of the mesh vertexes[x;y;x;y] in column first order.
//        IdEdgeX: nPixels-by-1, (x index) upper-left vertex of the quad including the p-th pixel.
//        IdEdgeY: nPixels-by-1, (y index) upper-left vertex of the quad including the p-th pixel.
//        [h,w]: image size.
//        [m,n]: Grid Size
//
//=====================Output=================================
//  plhs[0-1]: Xq, Yq
//      Xq: nPixels-by-1, the x index of original point corresponding to the distorted p-th pixel.
//      Yq: nPixels-by-1, the y index of original point corresponding to the distorted p-th pixel.
//
//=====================Description============================
//  This function calculate the IdQuad to calculate the distortion field defined by
//  Vertex. The backwards mapping (from target image to original image) is of vital
//  importance to implement the (bilinear) interpolation.
//

#include "mex.h"
#include "math.h"

void MySolve(double *u, double *v, double p, double q, double r, double s, double t, double w)
{
    //This function solves the equations with standard form:
    //  u*v+p*u+q*v+r==0 & s*u+t*v+w==0. s and t won't be zero simultaneously.
    if (s!=0)
    {
        if (t!=0)
        {
            //(u+q)*(v+p)+r-pq=0 & s(u+q)+t(v+p)+w-sq-tp=0
            // set x=s(u+q),y=t(v+p),a=st(pq-r),b=sq+tp-w;
            double a = s*t*(p*q-r);
            double b = s*q+t*p-w;
            double x1 = (b+sqrt(b*b-4*a))/2;
            double y1 = b-x1;
            *u = x1/s-q;
            if ((*u>=0) & (*u<=1))
                *v = y1/t-p;
            else
            {
                *u = y1/s-q;
                *v = x1/t-p;
            }
        }
        else
        {
            *u = -w/s;
            *v = (p*w/s-r)/(q-w/s);
        }
    }
    else
    {
        *v = -w/t;
        *u = (q*w/t-r)/(p-w/t);
    }
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    //  1.a) Check Inputs and Outpus
    if (nrhs!=7 || nlhs!=2)
    {
        mexErrMsgTxt("IO Fault, Please Check");
    }
    //  1.b) Read Inputs
    double *Vertex = mxGetPr(prhs[0]);
    double *IdEdgeX = mxGetPr(prhs[1]);
    double *IdEdgeY = mxGetPr(prhs[2]);
    double hh = mxGetScalar(prhs[3]);
    double ww = mxGetScalar(prhs[4]);
    int m = (int) mxGetScalar(prhs[5]);
    int n = (int) mxGetScalar(prhs[6]);
    int nPixels = (int) hh*ww;
    double xdis = ww/(n-1);
    // the distance between the neighboring regular mesh vertex along x axis.
    double ydis = hh/(m-1);

    //  1.c) Memory for Outputs
    plhs[0] = mxCreateDoubleMatrix(nPixels,1,mxREAL);
    double *Xq = mxGetPr(plhs[0]);
    plhs[1] = mxCreateDoubleMatrix(nPixels,1,mxREAL);
    double *Yq = mxGetPr(plhs[1]);

    //  2)  Main Loop
    int p;
    double x,y;
    int idex,idey;
    double Ax,Ay,Bx,By,Cx,Cy,Dx,Dy;// the coordinates of the (clockwise) four vertex of quad
    double a,b,c,d,e,f,g,h;
    double u,v;
    // the equations: a*u*v+b*u+c*v+d=0 & e*u*v+f*u+g*v+h=0.
    for (p=0; p<nPixels; p++)
    {
        //  2.a) Variables
        x = floor(p/hh)+1;// matlab index from 1, while C from 0.
        y = p-(x-1)*hh+1;
        idex = (int) IdEdgeX[p];
        idey = (int) IdEdgeY[p];
        Ax = Vertex[2*(idey+m*idex)]; Ay = Vertex[2*(idey+m*idex)+1];
        Bx = Vertex[2*(idey+m*(idex+1))]; By = Vertex[2*(idey+m*(idex+1))+1];
        Cx = Vertex[2*(idey+1+m*(idex+1))]; Cy = Vertex[2*(idey+1+m*(idex+1))+1];
        Dx = Vertex[2*(idey+1+m*idex)]; Dy = Vertex[2*(idey+1+m*idex)+1];

        a = Ax+Cx-Bx-Dx;  e = Ay+Cy-By-Dy;
        b = Dx-Cx;  f = Dy-Cy;// for regular mesh, b<0
        c = Bx-Cx;  g = By-Cy;// for regular mesh, g<0
        d = Cx-x;   h = Cy-y;

        //  2.b) Solve Equations to calculate u and v.
        if (a!=0)
        {
            if (e!=0)//a!=0 & e!=0
            {
                MySolve(&u,&v,b/a,c/a,d/a,f/e-b/a,g/e-c/a,h/e-d/a);
            }
            else//a!=0 & e==0
            {
                MySolve(&u,&v,b/a,c/a,d/a,f,g,h);
            }
        }
        else
        {
            if (e!=0)//a==0 & e!=0
            {
                MySolve(&u,&v,f/e,g/e,h/e,b,c,d);
            }
            else//a==0 & e==0
            {
                u = (c*h-d*g)/(b*g-c*f);
                v = (d*f-b*h)/(b*g-c*f);
            }
        }

        //  2.b.ii) Bugs when Mesh Longitudes Pass the Pixels, if exist Better Methods to improve?
        if ((u<0) | (u>1))
        {
            IdEdgeX[p] = ++idex;
            Ax = Vertex[2*(idey+m*idex)]; Ay = Vertex[2*(idey+m*idex)+1];
            Bx = Vertex[2*(idey+m*(idex+1))]; By = Vertex[2*(idey+m*(idex+1))+1];
            Cx = Vertex[2*(idey+1+m*(idex+1))]; Cy = Vertex[2*(idey+1+m*(idex+1))+1];
            Dx = Vertex[2*(idey+1+m*idex)]; Dy = Vertex[2*(idey+1+m*idex)+1];

            a = Ax+Cx-Bx-Dx;  e = Ay+Cy-By-Dy;
            b = Dx-Cx;  f = Dy-Cy;// for regular mesh, b<0
            c = Bx-Cx;  g = By-Cy;// for regular mesh, g<0
            d = Cx-x;   h = Cy-y;

            //  2.b) Solve Equations to calculate u and v.
            if (a!=0)
            {
                if (e!=0)//a!=0 & e!=0
                {
                    MySolve(&u,&v,b/a,c/a,d/a,f/e-b/a,g/e-c/a,h/e-d/a);
                }
                else//a!=0 & e==0
                {
                    MySolve(&u,&v,b/a,c/a,d/a,f,g,h);
                }
            }
            else
            {
                if (e!=0)//a==0 & e!=0
                {
                    MySolve(&u,&v,f/e,g/e,h/e,b,c,d);
                }
                else//a==0 & e==0
                {
                    u = (c*h-d*g)/(b*g-c*f);
                    v = (d*f-b*h)/(b*g-c*f);
                }
            }
        }

        //  2.c) Xq,Yq
        Xq[p] = xdis*(idex+1-u);
        Yq[p] = ydis*(idey+1-v);
    }
}
