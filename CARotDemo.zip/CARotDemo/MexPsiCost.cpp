//=====================Input==================================
//  prhs[0-5]: CandiPsi, ThetaBin, Uk, ek, beta, ll.
//        CandiPsi: K-by-N, The Candidate Psi.
//        Theta: M-by-1 vector, the common rorated angle of each bin.
//        IdBin: K-by-1 vector, the bin index of each LS directional vector.
//          ThetaBin === Theta(IdBin), K-by-1
//        Uk: K-by-2. the k-th row: [ Uk(1,1),Uk(2,1) ];
//        ek: K-by-2, the directional vector of the rotated LS.
//        beta: weighting parameter between line preservation and HQ-Splitting
//        ll: weighting parameter of the line preservation energy ( LambdaL in paper )
//
//
//=====================Output=================================
//  plhs[0]: PsiCost.
//      PsiCost: K-by-N, The energy of each Candidate Psi.
//
//=====================Description============================
//  This function calculate the PsiCost
//  to implement the Algorithm in <<Content-Aware Rotation>>.

#include "mex.h"
#include "math.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    //  1.a) Check Inputs and Outpus
    if (nrhs!=6 || nlhs!=1)
    {
        mexErrMsgTxt("IO Fault, Please Check");
    }
    //  1.b) Read Inputs
    double *CandiPsi = mxGetPr(prhs[0]);
    double *ThetaBin = mxGetPr(prhs[1]);
    double *Uk = mxGetPr(prhs[2]);
    double *ek = mxGetPr(prhs[3]);
    double beta = mxGetScalar(prhs[4]);
    double ll = mxGetScalar(prhs[5]);
    int K = (int) mxGetM(prhs[0]);
    int N = (int) mxGetN(prhs[0]);
    double w = ll/K;

    //  1.c) Memory for Outputs
    plhs[0] = mxCreateDoubleMatrix(K,N,mxREAL);
    double *PsiCost = mxGetPr(plhs[0]);

    //  2) Main Loop
    double u11,u21,u22,e1,e2,theta;
    double angle,cosrad,sinrad;
    double c2,s2,cs;
    double rui11,rui21,rui22;//The (1,1) and (2,1) element of the matrix Rk*Uk*Rk.'-In
    int ind;
    for (int k=0; k<K; k++)
    {
        u11 = Uk[k];
        u21 = Uk[K+k];
        u22 = 1-u11;
        e1 = ek[k];
        e2 = ek[K+k];
        theta = ThetaBin[k];
        for (int n=0; n<N; n++)
        {
            ind = k+n*K;
            angle = CandiPsi[ind];
            cosrad = cos(angle);
            sinrad = sin(angle);
            c2 = cosrad*cosrad;
            s2 = sinrad*sinrad;
            cs = cosrad*sinrad;
            rui11 = u11*c2+u22*s2-2*u21*cs-1;
            rui22 = -1-rui11;
            rui21 = (u11-u22)*cs+u21*(c2-s2);
            PsiCost[ind] = w*( pow(rui11*e1+rui21*e2,2)+pow(rui21*e1+rui22*e2,2) )
                    +beta*pow(angle-theta,2);
        }
    }
}
