function [] = PlotMesh( Vertex, rLs, cLs, Color, Wid )
%=====================Input==================================
%   Vx: rLs-by-cLs matrix. Vx(i,j) is the the x-coordinate
%       of the i-th (in row) and j-th (in column) vertex.
%   Vy(i,j) is corresponding y-coordinate.
%
%   Vertex: 2*rLs*cLs-by-1 vector, (x;y;x;y) in column-first order
%   GridSz: [rLs;cLs]
%=====================Output=================================
%
%=====================Description==============================
%   This function show the meshes on the displayed image.

narginchk(3,5);
Vx = reshape( Vertex( 1:2:end-1 ), rLs, cLs );
Vy = reshape( Vertex( 2:2:end ), rLs, cLs );

tmp = Vx(:,1);
tmp(tmp==0) = 1;
Vx(:,1) = tmp;

tmp = Vy(1,:);
tmp(tmp==0) = 1;
Vy(1,:) = tmp;

if ( nargin<4 || isempty(Color) ); Color = [1,1,0]; end;
if ( nargin<5 || isempty(Wid) ); Wid = 3; end;

hold on
plot( reshape([Vx;NaN(1,cLs)],1,[]), reshape([Vy;NaN(1,cLs)],1,[]), 'Color', Color, 'LineWidth', Wid );
plot( reshape(transpose([Vx,NaN(rLs,1)]),1,[]), reshape(transpose([Vy,NaN(rLs,1)]),1,[]), 'Color', Color, 'LineWidth', Wid );
plot( Vx(:), Vy(:), 'r+', 'MarkerSize', 10 );
hold off

end