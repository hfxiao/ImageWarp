//=====================Input==================================
//  prhs[0-2]: LS0, EdgeX, EdgeY.
//      LS0: K0-by-4 matrix, the original line segments.
//      EdgeX: 1-by-n, linspace(0,w,n).
//      EdgeY: 1-by-m, linspace(0,h,m).
//
//=====================Output=================================
//  plhs[0~3]: CutLS, IdLS0, IdEdgeX, IdEdgeY.
//      CutLS: K-by-4, the produced line segments cutted by the mesh edges.
//      IdLS0: K-by-1, IdLS0(k): the index of the LS0 containing CutLS(k).
//      IdEdgeX: K-by-1, (x index) upper-left vertex of the quad containing CutLS(k)
//      IdEdgeY: K-by-1, (y index) upper-left vertex of the quad containing CutLS(k)
//
//=====================Description============================
//  This function calculate the (new) line segments cutted by the mesh edges
//  to implement line segments colinearity constraint.

#include "mex.h"
#include "math.h"
#include <vector>

class LS
{
public:
    double x1,y1,x2,y2;
    int id0;
    LS(double z1=0, double w1=0, double z2=0, double w2=0, int id=0)
    {
        x1=z1;
        y1=w1;
        x2=z2;
        y2=w2;
        id0=id;
    }
    void SetLS(double z1, double w1, double z2, double w2,int id)
    {
        x1=z1;
        y1=w1;
        x2=z2;
        y2=w2;
        id0=id;
    }
};

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    //  1.a) Check Inputs and Outpus
    if (nrhs!=3 || nlhs!=4)
    {
        mexErrMsgTxt("IO Fault, Please Check");
    }

    //  1.b) Read Inputs
    double *LS0 = mxGetPr(prhs[0]);
    double *EdgeX = mxGetPr(prhs[1]);
    double *EdgeY = mxGetPr(prhs[2]);
    int K0 = (int) mxGetM(prhs[0]);
    double xdis = EdgeX[1];
    double ydis = EdgeY[1];

    //  2) LS0 Cutted by EdgeX, LSx calculated.
    std::vector<LS> LSx;
    LS TmpLS;

    int IdXi,IdXa;
    double x1,y1,x2,y2;// the x-y coordinate of the two ending points of LS0(k,:)
    int k,i;
    double tmpx,tmpy;
    double Cutx,Cuty;
    double slope, bias;
    for (k=0; k<K0; k++)
    {
        if (LS0[k]!=LS0[2*K0+k])
        {
            //  2.a) ensure x1<x2
            if (LS0[k]<LS0[2*K0+k])
            {
                x1 = LS0[k];
                y1 = LS0[K0+k];
                x2 = LS0[2*K0+k];
                y2 = LS0[3*K0+k];
            }
            else
            {
                x1 = LS0[2*K0+k];
                y1 = LS0[3*K0+k];
                x2 = LS0[k];
                y2 = LS0[K0+k];
            }

            //  2.b) The Interval of Cutting EdgeX
            IdXi = (int) floor(x1/xdis)+1;
            IdXa = (int) ceil(x2/xdis)-1;

            if (IdXa>=IdXi)// Cutting EdgeX Index: {IdXi:IdXa}
            {
                slope = (y2-y1)/(x2-x1);
                bias = (y1*x2-y2*x1)/(x2-x1);

                //  2.c) x1--Edge[IdXi]
                Cutx = EdgeX[IdXi];
                Cuty = slope*Cutx+bias;
                TmpLS.SetLS(x1,y1,Cutx,Cuty,k+1);
                LSx.push_back(TmpLS);

                //  2.d) IdXi<= i< IdXa
                for (i=IdXi; i<IdXa; i++)
                {
                    tmpx = Cutx;
                    tmpy = Cuty;
                    Cutx = EdgeX[i+1];
                    Cuty = slope*Cutx+bias;
                    TmpLS.SetLS(tmpx,tmpy,Cutx,Cuty,k+1);
                    LSx.push_back(TmpLS);
                }

                //  2.e) Edge[IdXa]--x2
                TmpLS.SetLS(Cutx,Cuty,x2,y2,k+1);
                LSx.push_back(TmpLS);
            }
            else// this (short) LS0 in a X-interval, not cutted
            {
                TmpLS.SetLS(x1,y1,x2,y2,k+1);
                LSx.push_back(TmpLS);
            }
        }
        else//x1==x2, parallel with EdgeX, will not be cut.
        {
            TmpLS.SetLS(LS0[k],LS0[K0+k],LS0[2*K0+k],LS0[3*K0+k],k+1);
            LSx.push_back(TmpLS);
        }
    }
    int Kx = LSx.size();

    //  3)  LSx Cutted by EdgeY, LSy calculated
    std::vector<LS> LSy;
    std::vector<double> IdEX;
    std::vector<int> IdEY;

    int IdYi,IdYa;
    for (k=0; k<Kx; k++)
    {
        if (LSx[k].y1!=LSx[k].y2)
        {
            //  3.a)    Read Ending Points
            //not ensured y1>y2, otherwise may not consistent with last LS
            x1 = LSx[k].x1;
            y1 = LSx[k].y1;
            x2 = LSx[k].x2;
            y2 = LSx[k].y2;

            //  3.b) The Interval of Cutting EdgeY
            if (y1<y2)
            {
                IdYi = (int) floor(y1/ydis)+1;
                IdYa = (int) ceil(y2/ydis)-1;

                if (IdYa>=IdYi)// Cutting EdgeY Index: {IdYi:IdYa}
                {
                    slope = (x2-x1)/(y2-y1);
                    bias = (x1*y2-x2*y1)/(y2-y1);

                    //  3.c) y1--Edge[IdYi]
                    Cuty = EdgeY[IdYi];
                    Cutx = slope*Cuty+bias;
                    TmpLS.SetLS(x1,y1,Cutx,Cuty,LSx[k].id0);
                    LSy.push_back(TmpLS);
                    IdEY.push_back(IdYi);
                    IdEX.push_back( ceil((Cutx>x1?Cutx:x1)/xdis) );

                    //  3.d) IdYi<= i< IdYa
                    for (i=IdYi; i<IdYa; i++)
                    {
                        tmpx = Cutx;
                        tmpy = Cuty;
                        Cuty = EdgeY[i+1];
                        Cutx = slope*Cuty+bias;
                        TmpLS.SetLS(tmpx,tmpy,Cutx,Cuty,LSx[k].id0);
                        LSy.push_back(TmpLS);
                        IdEY.push_back(i+1);
                        IdEX.push_back( ceil((Cutx>tmpx?Cutx:tmpx)/xdis) );
                    }

                    //  3.e) Edge[IdYa]--y2
                    TmpLS.SetLS(Cutx,Cuty,x2,y2,LSx[k].id0);
                    LSy.push_back(TmpLS);
                    IdEY.push_back(IdYa+1);
                    IdEX.push_back( ceil((x2>Cutx?x2:Cutx)/xdis) );
                }
                else// this (short) LSx in a Y-interval, not cutted
                {
                    TmpLS.SetLS(x1,y1,x2,y2,LSx[k].id0);
                    LSy.push_back(TmpLS);
                    IdEY.push_back(IdYi);
                    IdEX.push_back( ceil((x1>x2?x1:x2)/xdis) );
                }
            }
            else
            {
                IdYi = (int) floor(y2/ydis)+1;
                IdYa = (int) ceil(y1/ydis)-1;

                if (IdYa>=IdYi)// Cutting EdgeY Index: {IdYi:IdYa}
                {
                    slope = (x2-x1)/(y2-y1);
                    bias = (x1*y2-x2*y1)/(y2-y1);

                    //  3.c) y1--Edge[IdYa]
                    Cuty = EdgeY[IdYa];
                    Cutx = slope*Cuty+bias;
                    TmpLS.SetLS(x1,y1,Cutx,Cuty,LSx[k].id0);
                    LSy.push_back(TmpLS);
                    IdEY.push_back(IdYa+1);
                    IdEX.push_back( ceil((Cutx>x1?Cutx:x1)/xdis) );

                    //  3.d) IdYa>= i> IdYa
                    for (i=IdYa; i>IdYi; i--)
                    {
                        tmpx = Cutx;
                        tmpy = Cuty;
                        Cuty = EdgeY[i-1];
                        Cutx = slope*Cuty+bias;
                        TmpLS.SetLS(tmpx,tmpy,Cutx,Cuty,LSx[k].id0);
                        LSy.push_back(TmpLS);
                        IdEY.push_back(i);
                        IdEX.push_back( ceil((Cutx>tmpx?Cutx:tmpx)/xdis) );
                    }

                    //  3.e) Edge[IdYi]--y2
                    TmpLS.SetLS(Cutx,Cuty,x2,y2,LSx[k].id0);
                    LSy.push_back(TmpLS);
                    IdEY.push_back(IdYi);
                    IdEX.push_back( ceil((x2>Cutx?x2:Cutx)/xdis) );
                }
                else// this (short) LSx in a Y-interval, not cutted
                {
                    TmpLS.SetLS(x1,y1,x2,y2,LSx[k].id0);
                    LSy.push_back(TmpLS);
                    IdEY.push_back(IdYi);
                    IdEX.push_back( ceil((x1>x2?x1:x2)/xdis) );
                }
            }
        }
        else//y1==y2, parallel with EdgeY, will not be cut.
        {
            double tmp1,tmp2,tmp3,tmp4;
            tmp1 = LSx[k].x1;
            tmp3 = LSx[k].x2;
            tmp2 = LSx[k].y1;
            tmp4 = LSx[k].y2;

            TmpLS.SetLS(tmp1,tmp2,tmp3,tmp4,LSx[k].id0);
            LSy.push_back(TmpLS);
            IdEX.push_back( ceil((tmp1>tmp3?tmp1:tmp3)/xdis) );
            IdEY.push_back( ceil((tmp2>tmp4?tmp2:tmp4)/ydis) );
        }
    }
    int K = LSy.size();

    //  4)  Outputs from LSy
    plhs[0] = mxCreateDoubleMatrix(K,4,mxREAL);
    double *LS = mxGetPr(plhs[0]);
    plhs[1] = mxCreateDoubleMatrix(K,1,mxREAL);
    double *IdLS0 = mxGetPr(plhs[1]);
    plhs[2] = mxCreateDoubleMatrix(K,1,mxREAL);
    double *IdEdgeX = mxGetPr(plhs[2]);
    plhs[3] = mxCreateDoubleMatrix(K,1,mxREAL);
    double *IdEdgeY = mxGetPr(plhs[3]);
    for (k=0; k<K; k++)
    {
        LS[k] = LSy[k].x1;
        LS[K+k] = LSy[k].y1;
        LS[2*K+k] = LSy[k].x2;
        LS[3*K+k] = LSy[k].y2;
        IdLS0[k] = LSy[k].id0;
        IdEdgeX[k] = IdEX[k];
        IdEdgeY[k] = IdEY[k];
    }
    LSx.clear();
    LSy.clear();
    IdEX.clear();
    IdEY.clear();
}
