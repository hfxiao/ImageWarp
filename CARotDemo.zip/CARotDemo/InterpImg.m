function I1 = InterpImg( I0, Vertex, GridSz )
%=====================Input==================================
%   I0: h-by-w-by-3 double image, the original image
%   Vertex: 2*m*n-by-1 matrix, [x;y;x;y...] in column first order
%   GridSz: [m,n]
%=====================Output=================================
%   I1: h-by-w-3 RGB image, the interpolated image
%=====================Description==============================
%

[h,w,~] = size(I0);
m = GridSz(1); n = GridSz(2);

%   wrong: the original points mapped to the rorated points
% nPixels = h*w;
% nV = size(Vertex,1);
% [x,y]=meshgrid(1:w,1:h);
% x = reshape(x,[],1);
% y = reshape(y,[],1);
% xpos = linspace(0,w,n);
% ypos = linspace(0,h,m);
% xdis = w/(n-1);
% ydis = h/(m-1);
% IdEX = ceil( x/xdis ); % h*w-by-1
% IdEY = ceil( y/ydis );
% SubJ = [ 2*(IdEY+(IdEX-1)*m)-1, 2*(IdEY+(IdEX-1)*m) , 2*(IdEY+IdEX*m)-1, 2*(IdEY+IdEX*m),...
%             2*(IdEY+1+IdEX*m)-1, 2*(IdEY+1+IdEX*m) , 2*(IdEY+1+(IdEX-1)*m)-1, 2*(IdEY+1+(IdEX-1)*m) ]; % nPixels-by-8 subscript matrix
% Xq = zeros(nPixels,1);
% Yq = zeros(nPixels,1);
% for k = 1:nPixels
%     SEq = zeros(8,nV);
%     SEq( sub2ind( size(SEq), 1:8, SubJ(k,:) ) ) = 1;
%     mux = ( xpos(IdEX(k)+1)-x(k) )/xdis; % nPixels-by-1, the intepolation coefficients
%     muy = ( ypos(IdEY(k)+1)-y(k) )/ydis;
%     Xq(k) = [mux,0,1-mux,0,1-mux,0,mux,0]/2*SEq*Vertex;
%     Yq(k) = [0,muy,0,muy,0,1-muy,0,1-muy]/2*SEq*Vertex;
% end

% % %   right: finding the original points corresponding the given rotated points 
% % Vx = reshape( Vertex( 1:2:end-1 ), m, n );
% % Vy = reshape( Vertex( 2:2:end ), m, n );
% % [ Xq, Yq, IdEX, IdEY ] = MexXqYq( Vx, Vy, h, w );
% % [ Xq, Yq, ~, ~ ] = MexXqYq( Vx, Vy, h, w ); % Calculate the backward mapping defined by Vertex.
% [ Xq, Yq, ~, ~ ] = MexXqYq( reshape( Vertex( 1:2:end-1 ), m, n ), reshape( Vertex( 2:2:end ), m, n ), h, w );

%   right 2: 
[ IdEX, IdEY ] = MexInQuad( Vertex, h, w, m, n ); % bugs: leading wrong IdEXY when the pixels are on the longitude (lattitude) of the mesh @140314
[ Xq, Yq ] = MexQuadXYq( Vertex, IdEX-1, IdEY-1, h, w, m, n ); % matlab index from 1 while C from 0.
Xq = max(min(Xq,w),1); % to exclude the <1 or >w Xq values and avoid black holes.
Yq = max(min(Yq,h),1);
I1 = zeros(h,w,3);
for c = 1:3
    I1(:,:,c) = reshape( interp2( I0(:,:,c), Xq, Yq ), h, w );
end
I1 = uint8(I1);
figure(37); imshow(I1);
end