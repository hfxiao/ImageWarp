%   This file launches the implementation for the approach proposed in the paper 
%   "Kaiming He et al, Content-Aware Rotation, ICCV 2013".
%
%   The implementation is written by Hongfei Xiao (hfxiao.casia@gmail.com)


clc;close all;clear;
TaskName='CARot';
addpath(genpath('F:\Research\13-14\CARot'));% set your path here

%%  0)  Prepare functions
if exist(['lsd/lsd.', mexext],'file')==0
    mex -O -output lsd lsd_matlab.c lsd.c
end
if exist(['MexCutLS.', mexext],'file')==0
    mex MexCutLS.cpp
end
if exist(['MexPsiCost.', mexext],'file')==0
    mex MexPsiCost.cpp
end
if exist(['MexInQuad.', mexext],'file')==0
    mex MexInQuad.cpp
end
if exist(['MexQuadXYq.', mexext],'file')==0
    mex MexQuadXYq.cpp
end
% if exist(['MexXqYq.', mexext],'file')==0
%     mex MexXqYq.cpp
% end

%%  1)  Load the image and User Interaction
[FileName, ImgPath] = uigetfile('Images\*.*');
Img = imread(fullfile(ImgPath,FileName));
ImgName = FileName( 1:find( FileName=='.',1 )-1 );

%%  1.b)    User Interactions to set the rotation angle
imshow(Img);
set(gcf,'Name','Img','outerposition',get(0,'screensize'))
hold on;
UI = zeros(2, 2);
for i=1:2
    UI( i , : ) = ginput(1);%[c,r] co-ordinates
    plot( UI(i, 1), UI(i, 2), 'g+' );
end
hold off;

%%  2)  Options
Opt = CstOpt( 'ImgName',ImgName );

%%  3)  Run CARot & Display the Result
cc
tic
% [ ImgRot ] = CARot( double(Img), UI, Opt );
[ ImgRot ] = CARot( double(Img), UI, CstOpt( 'GridSz',[18,18] ) );
toc

%%  4)  Traverse Parameters