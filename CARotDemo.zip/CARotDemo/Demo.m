load im2.mat
addpath('lsd');
addpath('Images');

if exist(['lsd/lsd.', mexext],'file')==0
    mex -O -output lsd lsd_matlab.c lsd.c
end
if exist(['MexCutLS.', mexext],'file')==0
    mex MexCutLS.cpp
end
if exist(['MexPsiCost.', mexext],'file')==0
    mex MexPsiCost.cpp
end
if exist(['MexInQuad.', mexext],'file')==0
    mex MexInQuad.cpp
end
if exist(['MexQuadXYq.', mexext],'file')==0
    mex MexQuadXYq.cpp
end

tic
[ ImgRot ] = CARot( double(Img), UI, Opt );
toc