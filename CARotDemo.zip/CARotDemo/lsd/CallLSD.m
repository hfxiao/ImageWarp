function [ LS, RegImg, Kls ] = CallLSD( Img, FigId, scale, sigma_scale, quant, ang_th, eps, density_th, n_bins, Wid )
%=====================Input==================================
%   Img: h-by-w-by-3 uint8 RGB image or grayscale image
%
%=====================Output=================================
%
%=====================Description==============================
%   This is an interface written by Hongfei Xiao.
%   This interface is for calling the line segments detector proposed by [Rafael Grompone von Gioi et al., PAMI 2010]

%% 0)   Compile

%%  1)  Parse Inputs
narginchk(1,11);
if( nargin<2 || isempty(FigId)); FigId=19; end
if( nargin<3 || isempty(scale)); scale=0.8; end
if( nargin<4 || isempty(sigma_scale)); sigma_scale=0.6; end
if( nargin<5 || isempty(quant)); quant=2.0; end
if( nargin<6 || isempty(ang_th)); ang_th=22.5; end
if( nargin<7 || isempty(eps)); eps=0.0; end
if( nargin<8 || isempty(density_th)); density_th=0.7; end
if( nargin<9 || isempty(n_bins)); n_bins=1024; end
if( nargin<10 || isempty(Wid)); Wid=2; end

%% 2)   LSD Detection
tic;
if size(Img,3)==3
    % LS = lsd(double(rgb2gray(Img)), scale, sigma_scale, quant, ang_th, eps, density_th, n_bins, 255); % K0-by-5 matrix in version 1.5
%     LS = MexLsdC( double(rgb2gray(Img)), scale, sigma_scale, quant, ang_th, eps, density_th, n_bins ); % K0-by-7 matrix in version 1.6
    [ LS, RegImg ] = MexLSD( double(rgb2gray(Img)), scale, sigma_scale, quant, ang_th, eps, density_th, n_bins ); % K0-by-7 matrix in version 1.6
elseif size(Img,3)==1
    % LS = lsd(double(Img), scale, sigma_scale, quant, ang_th, eps, density_th, n_bins, 255); % K0-by-5 matrix in version 1.5
    % LS = MexLsdC( double(Img), scale, sigma_scale, quant, ang_th, eps, density_th, n_bins ); % K0-by-7 matrix in version 1.6
    [ LS, RegImg ] = MexLSD( double(Img), scale, sigma_scale, quant, ang_th, eps, density_th, n_bins ); % K0-by-7 matrix in version 1.6
end

%%  3)  Postprocess to Ensure the Regularity
[h,w,~] = size(Img);
%   3.a)    Remove the Line Segments Outside of the Image
LS = LS( LS(:,1)>0 & LS(:,3)>0 & LS(:,2)>0 & LS(:,4)>0 & LS(:,1)<w & LS(:,3)<w & LS(:,2)<h & LS(:,4)<h, : );
t = toc;
disp(['[lsd] ',num2str(t),' seconds elapsed.']);
Kls = size(LS,1);
disp([ num2str(Kls),' line segments have been detected.' ]);

%%  4)  Display
if FigId>0
    figure(FigId);
    if size(Img,3)==3
        imshow(uint8(Img));
    elseif size(Img,3)==1
        imshow(Img,[]);
    end
    hold on;
%     for i=1:Kls
%         plot(Lines(i,[1,3]),Lines(i,[2,4]),'Color',rand(1,3),'LineWidth',Wid);
%     end
    DispLineSeg( LS(:,1:4), [], [], Wid );
    hold off
    set(gcf,'Name','Line Segments Detection')%,'outerposition',get(0,'screensize'));
end

end