%% 
%  Copyright (c) 2011  Chen Feng (cforrest[at]umich[dot]edu)
%   and the University of Michigan
%
%   This program is free software; you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation; either version 2 of the License, or
%   (at your option) any later version.
% 
%   This program is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.

function Lines = CallLSD( Img, FigId, scale, sigma_scale, quant, ang_th, eps, density_th, n_bins, max_grad )
%   This function is adapted to LSD-v1.5, not for latest v1.6

%%  1)  Inputs
%   USAGE
%       BoundaryImg = DispBoundary( Img, Label, [OutColor], [InColor], [OutWidth], [InWidth], [FigId] )

narginchk(1,10);
if( nargin<2 || isempty(FigId)); FigId=19; end
if( nargin<3 || isempty(scale)); scale=0.8; end
if( nargin<4 || isempty(sigma_scale)); sigma_scale=0.6; end
if( nargin<5 || isempty(quant)); quant=2.0; end
if( nargin<6 || isempty(ang_th)); ang_th=22.5; end
if( nargin<7 || isempty(eps)); eps=0.0; end
if( nargin<8 || isempty(density_th)); density_th=0.7; end
if( nargin<9 || isempty(n_bins)); n_bins=1024; end
if( nargin<10 || isempty(max_grad)); max_grad=255; end

%% compile
% cd lsd
% mex -O -g -output lsd lsd_matlab.c lsd.c
% cd ..

%% test
tic
Lines = lsd(double(Img), scale, sigma_scale, quant, ang_th, eps, density_th, n_bins, max_grad); % K0-by-5 matrix in version 1.5
[H,W,~] = size(Img);
%   Remove the Line Segments Outside of the Image
Lines = Lines( Lines(:,1)>0 & Lines(:,3)>0 & Lines(:,2)>0 & Lines(:,4)>0 & Lines(:,1)<W & Lines(:,3)<W & Lines(:,2)<H & Lines(:,4)<H, 1:4 );
t = toc;
disp(['[lsd] ',num2str(t),' seconds elapsed.']);

nl = size(Lines,1);
disp( [num2str(nl),' line segments have been detected.']);
if FigId>0
    figure(FigId);
    imshow(uint8(Img));
    hold on;
    for i=1:nl
        plot(Lines(i,[1,3]),Lines(i,[2,4]),'r-');
    end
    hold off
end

end