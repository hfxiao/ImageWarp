//=====================Input==================================
//  prhs[0-4]: Vertex, h, w, m, n.
//        Vertex: nV-by-1, nV = 2*m*n. The image is covered by a m-by-n mesh.
//          the coordinates of the mesh vertexes[x;y;x;y] in column first order.
//        [h,w]: image size.
//        [m,n]: Grid Size
//
//=====================Output=================================
//  plhs[0-1]: IdEdgeX, IdEdgeY
//      IdEdgeX: nPixels-by-1, (x index) upper-left vertex of the quad including the pixel.
//      IdEdgeY: nPixels-by-1, (y index) upper-left vertex of the quad including the pixel.
//
//=====================Description============================
//  This function calculate the IdQuad to calculate the distortion field defined by
//  Vertex. The backwards mapping (from target image to original image) is of vital
//  importance to implement the (bilinear) interpolation.
//
//  This implementation is based on the prior that the IdEdgeXY
//  do not change a lot from the initial one.

#include "mex.h"
#include "math.h"

double mymax(double x1, double x2, double y1, double y2)
{
    double tmp1 = (x1>x2)?x1:x2;
    double tmp2 = (y1>y2)?y1:y2;
    return (tmp1>tmp2)?tmp1:tmp2;
}

bool IfWithin(double *Vertex, int m, int i, int j, int x, int y )
{
    //  1) Read the coordinate of the four vertexes. ABCD in clockwise.
    double Ax = Vertex[2*(j+m*i)];
    double Ay = Vertex[2*(j+m*i)+1];
    double Bx = Vertex[2*(j+m*(i+1))];
    double By = Vertex[2*(j+m*(i+1))+1];
    double Cx = Vertex[2*(j+1+m*(i+1))];
    double Cy = Vertex[2*(j+1+m*(i+1))+1];
    double Dx = Vertex[2*(j+1+m*i)];
    double Dy = Vertex[2*(j+1+m*i)+1];

    //  2)  Checking Point (x,y) whether within the Quad
    double aCof,bCof,cCof;
    //  2.a) AB
    aCof = By-Ay;   bCof = Ax-Bx;   cCof = (Bx*Ay-Ax*By);
    if ( (aCof*x+bCof*y+cCof)*(aCof*Cx+bCof*Cy+cCof)>=0 )
    {
        //  2.b) BC
        aCof = Cy-By;   bCof = Bx-Cx;   cCof = (Cx*By-Bx*Cy);
        if ( (aCof*x+bCof*y+cCof)*(aCof*Ax+bCof*Ay+cCof)>=0 )
        {
            //  2.b) CD
            aCof = Dy-Cy;   bCof = Cx-Dx;   cCof = (Dx*Cy-Cx*Dy);
            if ( (aCof*x+bCof*y+cCof)*(aCof*Ax+bCof*Ay+cCof)>=0 )
            {
                //  2.b) DA
                aCof = Ay-Dy;   bCof = Dx-Ax;   cCof = (Ax*Dy-Dx*Ay);
                if ( (aCof*x+bCof*y+cCof)*(aCof*Cx+bCof*Cy+cCof)>=0 )
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        else
            return false;
    }
    else
        return false;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    //  1.a) Check Inputs and Outpus
    if (nrhs!=5 || nlhs!=2)
    {
        mexErrMsgTxt("IO Fault, Please Check");
    }
    //  1.b) Read Inputs
    double *Vertex = mxGetPr(prhs[0]);
    int h = (int) mxGetScalar(prhs[1]);
    int w = (int) mxGetScalar(prhs[2]);
    int m = (int) mxGetScalar(prhs[3]);
    double n = mxGetScalar(prhs[4]);
    int nPixels = h*w;

    //  1.c) Memory for Outputs
    plhs[0] = mxCreateDoubleMatrix(nPixels,1,mxREAL);
    double *IdEdgeX = mxGetPr(plhs[0]);
    plhs[1] = mxCreateDoubleMatrix(nPixels,1,mxREAL);
    double *IdEdgeY = mxGetPr(plhs[1]);

    //  2) Main Loop
    double xdis = w/(n-1);
    double ydis = h/((double)m-1);
    double idex0,idey0;
    int p,x,y;
    int r,rmax;// r: the radius of the searching neighboring domain. rmax: possible maximum r.
    int idr;// the index of the points on the searching neighboring domain (r)
    int flag;//whether the quad index has been found
    int i,j;// the column row index of Quads.
    for (p=0; p<nPixels; p++)
    {
        //  2.a) initial guess according to initial mesh(partition the image equally difference).
        x = p/h;
        y = p-x*h;
        idex0 = floor(x/xdis);
        idey0 = floor(y/ydis);

        //  2.b) Check for radius==0
        if (IfWithin(Vertex, m, (int)idex0, (int)idey0, x, y ))
        {
            IdEdgeX[p] = idex0+1;//matlab index from 1 while C from 0.
            IdEdgeY[p] = idey0+1;
            continue;
        }

        //  2.c) while loop to check radius = 1:infinity
        flag = 0;
        rmax = mymax(idex0,n-1-idex0,idey0,m-1-idey0);
        for (r = 1; r<rmax; r++)
        {
            for (idr=0;idr<8*r;idr++)
            {
                switch (idr/(2*r))
                {
                case 0:// idr\in{0:2*r-1}
                {
                    j = idey0-r;// the row index of Quads. (along y axis)
                    i = idex0+idr-r;// the column index of Quads.(along x axis)
                    if (0<=i && i<n-1 && 0<=j &&j<m-1)
                    {
                        if (IfWithin(Vertex, m, i, j, x, y ))
                        {
                            IdEdgeX[p] = i+1;
                            IdEdgeY[p] = j+1;
                            flag = 1;
                        }
                    }
                    break;
                }
                case 1:// idr\in{2*r:4*r-1}
                {
                    j = idey0+idr-3*r;// the row index of Quads. (along y axis)
                    i = idex0+r;// the column index of Quads.(along x axis)
                    if (0<=i && i<n-1 && 0<=j &&j<m-1)
                    {
                        if (IfWithin(Vertex, m, i, j, x, y ))
                        {
                            IdEdgeX[p] = i+1;
                            IdEdgeY[p] = j+1;
                            flag = 1;
                        }
                    }
                    break;
                }
                case 2:// idr\in{4*r:6*r-1}
                {
                    j = idey0+r;// the row index of Quads. (along y axis)
                    i = idex0+5*r-idr;// the column index of Quads.(along x axis)
                    if (0<=i && i<n-1 && 0<=j &&j<m-1)
                    {
                        if (IfWithin(Vertex, m, i, j, x, y ))
                        {
                            IdEdgeX[p] = i+1;
                            IdEdgeY[p] = j+1;
                            flag = 1;
                        }
                    }
                    break;
                }
                case 3:// idr\in{6*r:8*r-1}
                {
                    j = idey0+7*r-idr;// the row index of Quads. (along y axis)
                    i = idex0-r;// the column index of Quads.(along x axis)
                    if (0<=i && i<n-1 && 0<=j &&j<m-1)
                    {
                        if (IfWithin(Vertex, m, i, j, x, y ))
                        {
                            IdEdgeX[p] = i+1;
                            IdEdgeY[p] = j+1;
                            flag = 1;
                        }
                    }
                    break;
                }
                }
                if (flag==1)
                    break;
            }
            if (flag==1)
                break;
        }
    }
}
